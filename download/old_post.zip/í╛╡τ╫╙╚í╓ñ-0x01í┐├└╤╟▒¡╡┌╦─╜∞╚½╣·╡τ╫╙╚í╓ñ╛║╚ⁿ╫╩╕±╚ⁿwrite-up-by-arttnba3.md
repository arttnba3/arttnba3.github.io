---
title: 【电子取证-0x01】美亚杯第四届全国电子取证竞赛资格赛write up by arttnba3
date: 2020-10-06 00:20:22
tags:
	- 电子取证
	- 美亚杯
categories: 电子取证
---

# 0x00.绪论

[“美亚杯”中国电子数据取证大赛](http://meiyacup.com)是由**中国刑事警察学院主办、厦门美亚柏科承办的中国电子数据取证大赛**，也是国内较为有名的数据取证比赛

作为网安专业的小萌新去年对此毫不知情（~~知情了我可能也过不了资格赛~~），于是今年想要去玩玩（~~指划水~~），所以打算趁时间还够把过去的几次比赛的真题给刷一刷XD

<!--more-->

> 注：本人感觉取证比赛就是熟练运用各种工具的比赛...（~~取证软件公司的硬广~~

# 0x01.工具

**硬件：**

- Microsoft Surface Book 2
- Samsung 500G SSD

**软件：**

- 取证大师**试用版**
- AccessData FTK Imager
- DiskGenius

# 0x02.资格赛 - 案情介绍

> 1.林胜（Victor）是一名三十岁的中学教师。一天，他在家中使用计算机期间，收到一封勒索邮件，其中列出他电子邮件用户名和密码，及其他個人资料，並声称他的用户数据已被窃取，计算机已被入侵。黑客向林胜勒索**两个比特币**，否则会使用他的个人用户数据作非法用途。林无力支付，于是报警，并向警方提供了他的个人计算机作检验。
>
> ![image.png](https://i.loli.net/2020/10/06/PRyuzoVedDlEBbw.png)
>
> 2.现你被委派对林的计算机进行电子数据取证，还原事件经过。

本次比赛共1 个章节，50 个小题，每题2分，总共100分，比赛时长118 分钟。

# 0x03.资格赛 - 单项选择题

我们选择使用**取证大师**这一取证软件进行我们的取证工作

新建案例→添加镜像→Victor_PC.E01

等待自动分析完成，我们可以看到镜像的所有信息在我们面前一览无余

![image.png](https://i.loli.net/2020/10/06/7oyvcFkA8zfs9R5.png)

## 1.Victor的笔记本电脑己成功取证并制作成法证映像档 (Forensic Image)，下列哪个是其MD5哈希值?

> A. FC20782C21751AB76B2A93F3A17922D0
>
> B. 882114D62E713DEA34C270CF2F1C69D2
>
> C. A0BB016160CFB3A0BB0161661670CFB3
>
> D. 917ED59083C8B35C54D3FCBFE4C4BB0B
>
> E. FC20782C21751BA76B2A93F3A17922D0

在取证大师下方的【摘要】一栏中我们可以看到其MD5值应为**FC20782C21751BA76B2A93F3A17922D0**

![image.png](https://i.loli.net/2020/10/06/N1nHTdcCOm4K68V.png)

## 2.根据法证映像档 (Forensic Image)，确定原笔记本内有多少个硬盘分区?

> A. 1
>
> B. 2
>
> C. 3
>
> D. 4
>
> E. 5

在左边栏中我们可以看到镜像内有三个硬盘分区

![image.png](https://i.loli.net/2020/10/06/exhEMocuCbKIVwQ.png)

## 3.你能找到硬盘操作系统分区内的开始逻辑区块地址（LBA）? (答案格式: 扇区, Sector)

> A. 0
>
> B. 2408
>
> C. 1048576
>
> D. 62916608
>
> E. 32213303296

首先我们分析各磁盘中文件结构，不难看出**E盘应当是系统盘**

![image.png](https://i.loli.net/2020/10/06/X6ZFHqhTQcEj1lx.png)

在【摘要】中我们可以看出其开始逻辑区块地址应为**32,213,303,296**

![image.png](https://i.loli.net/2020/10/06/qTtHYUcEJjDyOLh.png)

## 4.你能找到硬盘操作系统分区的物理大小吗 (字节byte)?

> A. 62709760
>
> B. 62910464
>
> C. 104857600
>
> D. 32107397120
>
> E. 32210157568

首先在摘要中我们可以得知**每个扇区的大小为512 Byte**

![image.png](https://i.loli.net/2020/10/06/9AeOzGDJi7LcQoa.png)

系统盘中一共有**62,910,464**个扇区

![image.png](https://i.loli.net/2020/10/06/qTtHYUcEJjDyOLh.png)

于是我们可以计算出系统盘的物理大小应为**32,210,157,568 Bytes**

> 可以使用python辅助计算（计算器当然也行XD只不过我第一时间想起来的就是python（👈把这个天天说废话的人拖出去打死
> ```powershell
> PS C:\WINDOWS\system32> python
> Python 3.7.4 (tags/v3.7.4:e09359112e, Jul  8 2019, 19:29:22) [MSC v.1916 32 bit (Intel)] on win32
> Type "help", "copyright", "credits" or "license" for more information.
> >>> 512*62910464
> 32210157568
> ```

> 当我把摘要往下翻才发现原来摘要里就有...好气啊...
>
> ![image.png](https://i.loli.net/2020/10/06/XjOChmZJEQnk4Iy.png)

## 5.操作系统分区的文件系统是哪种?

> A. FAT32
>
> B. EXFAT
>
> C. NTFS
>
> D. EXT3
>
> E. HFS+

在【摘要】中我们可以看出其文件系统应该为**NTFS**

![image.png](https://i.loli.net/2020/10/06/qTtHYUcEJjDyOLh.png)

## 6.操作系统分区，每个簇(Cluster)包含几个扇区(sectors)?

> A. 2
>
> B. 4
>
> C. 6
>
> D. 8
>
> E. 16

emmmm这道题我是用比较笨的方法来做的（因为刚开始学电子取证XD

首先使用**AccessData FTK Imager**将镜像里的三个盘挂载到自己电脑上

![image.png](https://i.loli.net/2020/10/06/aHURQw1P38ktSmK.png)

然后使用**DiskGenius**查看分区可知**簇大小为4096 Byte**

![image.png](https://i.loli.net/2020/10/06/foJDFj5dOrMi6sB.png)

前面我们已知单个扇区为**512 Byte**，故每个簇包含 4096 / 512 = **8 ** 个扇区

## 7.在操作系统分区内，$MFT的物理起始扇区位置(Starting physical sector)是什么?

> A. 62,919,936
>
> B. 67,086,648
>
> C. 68,942,784
>
> D. 69,208,064
>
> E. 79,865,960

在取证大师中我们可以看出其物理起始扇区位置应为**69,208,064**

![image.png](https://i.loli.net/2020/10/06/y5zQqL8KdICjAGl.png)

## 8.请找出系统文件“SOFTWARE＂，请问操作系统的安装日期是? （答案格式 －“世界协调时间＂：YYYY-MM-DD HH:MM UTC）

> A. 2018-10-25 08:08 UTC
>
> B. 2018-10-25 08:09 UTC
>
> C. 2018-10-25 08:10 UTC
>
> D. 2018-10-25 08:11 UTC
>
> E. 2018-10-25 08:12 UTC

使用取证大师我们可以很方便地找到我们所需的文件并将之提取出来

![RONVO_P~1_8JDDEBG~UJEA1.png](https://i.loli.net/2020/10/06/l2Ck9otVxUnKBwb.png)

![3S0G_N35TRPDI_9ACZBKT_W.png](https://i.loli.net/2020/10/06/Cm5WqZti43RBHg6.png)

同样的我们使用取证大师也可以看到其系统安装时间为**2018-10-25 16:08:39**

> （**注：我们所处的时区为UTC+8，所以答案应该再减去8h**）

![image.png](https://i.loli.net/2020/10/06/6KlSf7RnQruiMXL.png)

## 9.用户“victor＂的唯一标识符(SID)是什么?（答案格式：RID）

> A. 1001
>
> B. 1002
>
> C. 1003
>
> D. 1004
>
> E. 1005

使用取证大师我们可以在【用户信息】一栏很方便地看到每个用户的信息，包括SID，其中**用户victor的SID为1001**

![image.png](https://i.loli.net/2020/10/06/4IFwv7mJGpHeU6o.png)

## 10.用户“Lily＂的唯一标识符(SID)是什么?（答案格式：RID）

> A. 1001
>
> B. 1002
>
> C. 1003
>
> D. 1004
>
> E. 1005

使用取证大师我们可以很方便地看到每个用户的SID，其中**用户Lily的SID为1003**

![image.png](https://i.loli.net/2020/10/06/4IFwv7mJGpHeU6o.png)

## 11.Victor上一次更改系统登入密码是? （答案格式 －“本地时间＂：YYYY-MM-DD HH:MM +8）

> A. 2018-11-01 16:08 +8
>
> B. 2018-11:01 14:15 +8
>
> C. 2018-10-26 17:00 +8
>
> D. 2018-10-25 08:08 +8
>
> E. 2018-10-25 16:08 +8

我们可以使用取证大师得到用户victor上次修改密码的时间应为 **2018-10-25 16:08:37 + 8**

![image.png](https://i.loli.net/2020/10/06/rGKXT2lgp8avNYD.png)

## 12.Lily上一次更改系统登入密码是? （答案格式 －“本地时间＂：YYYY-MM-DD HH:MM +8）

>  A. 2018-11-01 03:02:01 +8
>
> B. 2018-11:02 11:13:33 +8
>
> C. 2018-10-26 17:00:45 +8
>
> D. 2018-10-30 12:30:40 +8
>
> E. 2018-10-27 12:08:37 +8

同样地我们可以得到用户Lily上次修改密码的时间应为 **2018-10-30 12:30:40 + 8**

![image.png](https://i.loli.net/2020/10/06/rGKXT2lgp8avNYD.png)

## 13.Victor 总共登录系统多少次?

> A. 3
>
> B. 16
>
> C. 33
>
> D. 36
>
> E. 45

通过取证大师我们可以看到victor总共登录了**36次**

![image.png](https://i.loli.net/2020/10/06/jhS3ZF7YiEbUuGk.png)

## 14.以下哪个帐号已经被禁用?

> A. Administrator
>
> B. victor
>
> C. Lily
>
> D. simon
>
> E. 以上皆不是

在取证大师中我们可以看到**Administrator账户处于禁用状态**

![image.png](https://i.loli.net/2020/10/06/R9EHNgJZIslXnjY.png)

## 15.以下哪个帐系统权限最低?

> A. Administrator
>
> B. victor
>
> C. Lily
>
> D. simon
>
> E. 以上权限一样

Simon账户处在Guests用户组，权限最低

![image.png](https://i.loli.net/2020/10/06/R9EHNgJZIslXnjY.png)

## 16.以下哪个帐号曾经远端登录系统?

> A. Administrator
>
> B. victor
>
> C. Lily
>
> D. simon
>
> E. 远端登入已被禁止

emmm看了一圈发现没有账号有远端登入的记录，只能大胆猜测远端登入已被禁止了XDD

后面或许能够找到这题的正确解法（瘫

## 17.硬盘操作系统的版本?

> A. Windows 7 Enterprise (32 位)
>
> B. Windows 7 Enterprise (64 位)
>
> C. Windows 7 Professional (32 位)
>
> D. Windows 7 Professional (64 位)
>
> E. Windows 7 Ultimate (64 位)

取证大师中我们可以看到系统版本为**64位的Win7 Professional**

![image.png](https://i.loli.net/2020/10/06/6KlSf7RnQruiMXL.png)

## 18.操作系统的最新服务包(Service Pack)版本号是什么? 

> A. Service Pack 1
>
> B. Service Pack 2
>
> C. Service Pack 3
>
> D. Service Pack 4
>
> E. Service Pack 5

 还是在取证大师中我们可以看到最新服务包为**Service Pack 1**

![image.png](https://i.loli.net/2020/10/06/6KlSf7RnQruiMXL.png)

## 19.下列哪个是victor的默认打印机?

> A. HP OfficeJet 250 Mobile Series
>
> B. CutePDF Writer
>
> C. Microsoft XPS Document Writer
>
> D. PDF Complete
>
> E. AL-M2330

